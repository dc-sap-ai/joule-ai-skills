# Changelog

All notable changes to the SAP Product Explainer skill are documented here.

## [1.1.0] — 2026-10-05

### Changed
- Quick Overview and Detailed Overview now delivered exclusively as render_ui visual cards (no prose markdown)
- Quick Overview card fields: Product, What it is, SAP Store, Portfolio, Line of Business, CPO, SLA, Demo
- Detailed Overview card fields: Product, What it is, SAP Store, Portfolio, Line of Business, CPO, Components & Integrations, Key Capabilities, Operations Contact, SLA, Regions Available, Infrastructure, Demo, Who typically uses it
- Step 1 expanded to 5 parallel searches (added demo + SLA/regions/infra searches)
- Step 3 expanded to 3 parallel searches (added ops contact + infra searches)
- Added render_ui to allowed tools

### Added
- New fields in Detailed Overview: Operations Contact, SLA, Regions Available, Infrastructure
- New field in Quick Overview: SLA, Demo

## [1.0.0] — 2026-10-05

### Added
- Initial release with Quick Overview and Detailed Overview
- Parallel web searches (3 for quick, 2 for detailed)
- Adaptive output: quick first, detailed on confirmation
- CPO attribution, SAP Store link, Portfolio tree
